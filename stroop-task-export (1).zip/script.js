// Define study
const study = lab.util.fromObject({
  "messageHandlers": {},
  "title": "root",
  "type": "lab.flow.Sequence",
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.Download",
      "filePrefix": "stroop-task",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "Stroop task",
    "description": "An implementation of the classic paradigm introduced by Stroop (1935).",
    "repository": "https:\u002F\u002Fgithub.com\u002Ffelixhenninger\u002Flab.js\u002Fexamples\u002F",
    "contributors": "Felix Henninger \u003Cmailbox@felixhenninger.com\u003E (http:\u002F\u002Ffelixhenninger.com)"
  },
  "parameters": {},
  "files": {},
  "responses": {},
  "content": [
    {
      "messageHandlers": {},
      "type": "lab.html.Screen",
      "responses": {
        "keypress(Space)": "continue"
      },
      "title": "START",
      "content": "\u003Cmain\u003E\n\u003Ch1\u003E Welkom bij deze computertaak. \u003C\u002Fh1\u003E\n\u003Cp\u003E Via deze computertaak zullen we jouw \u003Ci\u003Einhibitorische controle\u003C\u002Fi\u003E trachten te meten. \u003C\u002Fp\u003E\n\u003Cbr\u003E\n\u003Cp\u003E\nConcreet zullen we nagaan in welke mate je in staat bent om \u003Cb\u003Ezo snel en zo goed \u003C\u002Fb\u003E mogelijk te reageren op een gepresenteerde \u003Ci\u003E'GO' stimulus\u003C\u002Fi\u003E, maar ondertussen ook een reactie te onderdrukken bij de presentatie van een \u003Ci\u003E'NO GO' stimulus\u003C\u002Fi\u003E. \u003C\u002Fp\u003E\n  \u003Cbr\u003E\n\n\n\u003C\u002Fmain\u003E\n\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\n  \u003Ch4\u003E\u003Cb\u003EDruk op de \u003Ckbd\u003E spatiebalk \u003C\u002Fkbd\u003E om verder te gaan.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \n\u003C\u002Ffooter\u003E",
      "parameters": {},
      "files": {}
    },
    {
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
this.options.events['keypress(Space)'] = (event) => {
  // Find the form on the page ...
  var form = this.options.el.querySelector('form')

  // ... and submit the screen
  this.submit(event)
}
}
      },
      "type": "lab.html.Screen",
      "responses": {
        "keypress(Space)": "continue"
      },
      "title": "INPUT",
      "content": "\u003Cmain\u003E\n  \u003Cp\u003EVul hier jouw participantnummer in, die je terugvindt op de jouw intake vragenlijst. Dubbelcheck jouw participantnummer zodat er hier zeker geen fouten gebeuren.\n    \u003Cform\u003E\n      \u003Cinput type =\"number\" name = \"participantnummer\" id = \"participantnr\"\n      placeholder = \"participantnummer\" required\u003E\n    \u003C\u002Fform\u003E\u003C\u002Fp\u003E\n    \u003Cbr\u003E\n\u003C\u002Fmain\u003E\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\n  \u003Ch4\u003E\u003Cb\u003EDruk op de \u003Ckbd\u003E spatiebalk \u003C\u002Fkbd\u003E om verder te gaan.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \n\u003C\u002Ffooter\u003E",
      "parameters": {},
      "files": {}
    },
    {
      "messageHandlers": {},
      "type": "lab.html.Screen",
      "responses": {
        "keypress(Space)": "continue"
      },
      "title": "UITLEG",
      "content": "\u003Cmain\u003E\n  \u003Cp\u003E Zoals reeds aangegeven aan het begin van deze computertaak, zullen we testen in welke mate je in staat bent om zo snel mogelijk te reageren op een gepresenteerde \u003Cspan style=\"color: green;\"\u003E\u003Ci\u003E'GO' stimulus\u003C\u002Fi\u003E\u003C\u002Fspan\u003E, maar ondertussen ook een reactie te onderdrukken bij de presentatie van een \u003Cspan style=\"color: red;\"\u003E\u003Ci\u003E'NO GO' stimulus\u003C\u002Fi\u003E\u003C\u002Fspan\u003E. \u003Cp\u003E\n\u003Cbr\u003E\n\u003Cp\u003E We zullen twee blokken doorlopen, waarbij je afbeeldingen te zien zal krijgen waar je juist wél of juist niét op moet reageren. De afbeeldingen waarop je moet reageren zal echter wisselen tussen de twee blokken. \u003C\u002Fp\u003E\n\u003Cbr\u003E\n\u003Cp\u003E Bij het ene blok zal je zo snel mogelijk moeten reageren op de logo's van \u003Cb\u003EInstagram, Facebook, Messenger en Whatsapp\u003C\u002Fb\u003E (= \u003Cspan style=\"color: green;\"\u003EGO\u003C\u002Fspan\u003E) en ondertussen niet reageren op de afbeeldingen waar deze logo's verhakkelt zijn (= \u003Cspan style=\"color: red;\"\u003ENO GO\u003C\u002Fspan\u003E). In het andere blok zal je net zo snel mogelijk moeten reageren op deze \u003Ci\u003E'verhakkelde'\u003C\u002Fi\u003E logo's (= \u003Cspan style=\"color: green;\"\u003EGO\u003C\u002Fspan\u003E) en mag je niet reageren op de vier \u003Ci\u003E'normale'\u003C\u002Fi\u003E logo's (= \u003Cspan style=\"color: red;\"\u003ENO GO\u003C\u002Fspan\u003E). Dit zal voor elk van beide blokken verduidelijkt worden.\u003C\u002Fp\u003E\n\u003Cbr\u003E\n\u003Cbr\u003E\n\u003Cp\u003E Wanneer je moet reageren op een afbeelding, doe je dit door zo snel mogelijk op \u003Ckbd\u003E\u003Cb\u003EJ\u003C\u002Fb\u003E\u003C\u002Fkbd\u003E te drukken. \u003C\u002Fp\u003E\n\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\n  \u003Ch4\u003E\u003Cb\u003EDruk op de \u003Ckbd\u003E spatiebalk \u003C\u002Fkbd\u003E om te concrete uitleg te krijgen over blok 1. \u003C\u002Fh4\u003E\u003C\u002Fb\u003E \n\u003C\u002Ffooter\u003E\n",
      "parameters": {},
      "files": {}
    },
    {
      "type": "lab.flow.Sequence",
      "parameters": {},
      "responses": {},
      "messageHandlers": {},
      "title": "BLOK 1 (GO = SNS)",
      "files": {},
      "content": [
        {
          "messageHandlers": {},
          "type": "lab.html.Screen",
          "responses": {
            "keypress(Space)": "continue"
          },
          "title": "UITLEG BLOK 1  (GO = SNS)",
          "content": "\u003Cmain\u003E\n  \u003Ch1\u003E BLOK 1 (GO = SNS) \u003C\u002Fh1\u003E\n  \u003Cp\u003E Tijdens dit eerste blok zal je moeten reageren op de logo's van \u003Cb\u003E social media en communicatie-applicaties \u003C\u002Fb\u003E, nl. Instagram, Facebook, Messenger, Whatsapp.\u003C\u002Fp\u003E\n  \u003Cbr\u003E\n  \u003Cimg src=\"${ this.files['samen_knip.jpg'] }\" height= auto width= 350\u003E\n  \u003Cbr\u003E\n  \u003Cp\u003E Als je deze logo's ziet verschijnen, druk je zo snel mogelijk op \u003Ckbd\u003EJ\u003C\u002Fkbd\u003E. Wanneer je de 'verhakkelde' logo's te zien krijg, mag je \u003Cb\u003Eniet reageren\u003C\u002Fb\u003E en wacht je tot die afbeeldingen verdwijnen. Hier probeer je dus juist \u003Cb\u003E niet \u003C\u002Fb\u003E reageren. \u003C\u002Fp\u003E\n  \u003Cbr\u003E\n\u003C\u002Fmain\u003E\n\u003Cfooter class = \"content-vertical-center content-horizontal-center\"\u003E\n   \u003Ch4\u003E\u003Cb\u003EDruk op de \u003Ckbd\u003E spatiebalk \u003C\u002Fkbd\u003E om een visualisatie te zien van deze taak.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \n\u003C\u002Ffooter\u003E\n",
          "parameters": {},
          "files": {
            "samen_knip.jpg": "embedded\u002F94194ba99fdcd7a9bee43aafd59631dd990bdf4df280bf0e6223979de9806e41.jpg"
          }
        },
        {
          "messageHandlers": {},
          "type": "lab.html.Screen",
          "responses": {
            "keypress(Space)": "continue"
          },
          "title": "VISUAL UITLEG BLOK 1 (GO = SNS)",
          "content": "\u003Cmain\u003E\n   \u003Cp\u003E Hieronder krijg je een visualisatie van de voorgaande uitleg over hoe je moet reageren tijdens dit eerste blok. \u003C\u002Fp\u003E\n  \u003Cbr\u003E\n  \u003Cp\u003E Concreet moet je dus op \u003Ckbd\u003E J \u003C\u002Fkbd\u003E bij de volgende vier logo's: \u003C\u002Fp\u003E\n\n \u003Cimg src=\"${ this.files['samen_knip.jpg'] }\" height= auto width= 350\u003E\n  \n\u003Cbr\u003E\n\n \u003C\u002Fmain\u003E\n \u003Cfooter class = \"content-vertical-center content-horizontal-center\"\u003E\n   \u003Ch4\u003E\u003Cb\u003EDruk op de \u003Ckbd\u003E spatiebalk \u003C\u002Fkbd\u003E om te starten met het eerste blok.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \n\u003C\u002Ffooter\u003E\n",
          "parameters": {},
          "files": {
            "samen_knip.jpg": "embedded\u002F94194ba99fdcd7a9bee43aafd59631dd990bdf4df280bf0e6223979de9806e41.jpg"
          }
        },
        {
          "type": "lab.flow.Loop",
          "parameters": {},
          "templateParameters": [
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "GO"
            }
          ],
          "responses": {},
          "messageHandlers": {},
          "title": "BLOK 1 LOOP",
          "files": {},
          "sample": {
            "mode": "draw",
            "n": "10"
          },
          "shuffleGroups": [],
          "template": {
            "type": "lab.flow.Sequence",
            "parameters": {},
            "responses": {},
            "messageHandlers": {},
            "title": "BLOK 1 TRIAL",
            "files": {},
            "content": [
              {
                "type": "lab.html.Screen",
                "parameters": {},
                "responses": {},
                "messageHandlers": {},
                "title": "FIXATION",
                "content": "\u003Cmain class=\"content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Cdiv style=\"font-size: 3.5rem\"\u003E\r\n    +\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fmain\u003E\r\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Cp\u003E\u003Ch4\u003E\r\n    Druk op zo snel mogelijk op \u003Ckbd\u003EJ\u003C\u002Fkbd\u003E indien je het logo van Instagram, Facebook, Messenger of Whatsapp te zien krijgt. \r\n  \u003C\u002Fp\u003E\u003C\u002Fh4\u003E\r\n\u003C\u002Ffooter\u003E",
                "timeout": "200",
                "files": {}
              },
              {
                "type": "lab.html.Screen",
                "parameters": {},
                "responses": {
                  "keypress(j) window": "GO"
                },
                "messageHandlers": {},
                "title": "STIMULUS",
                "content": "\u003Cstyle\u003E\r\n  .topleft {\r\n    position: absolute;\r\n    top: 150px;\r\n    left: 40px;\r\n    font-size: 30px;\r\n  }\r\n  .topright {\r\n    position: absolute;\r\n    top: 150px;\r\n    right: 40px;\r\n    font-size: 30px;\r\n  }\r\n\u003C\u002Fstyle\u003E  \r\n\u003Cheader\u003E\r\n Indien nodig, reageer op de afbeelding. \r\n\u003C\u002Fheader\u003E\r\n\r\n\u003Cmain\u003E\r\n  \u003Cimg src=\"${ this.files[ parameters.STIMULI ] }\" height= auto width= 350\u003E\r\n\r\n\u003C\u002Fmain\u003E\r\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Cp\u003E\u003Ch4\u003E\r\n    Druk op zo snel mogelijk op \u003Ckbd\u003EJ\u003C\u002Fkbd\u003E indien je het logo van Instagram, Facebook, Messenger of Whatsapp te zien krijgt. \r\n  \u003C\u002Fp\u003E\u003C\u002Fh4\u003E\r\n\u003C\u002Ffooter\u003E",
                "timeout": "1500",
                "files": {
                  "Messenger_scram.jpg": "embedded\u002Fa79abe0617b0d2631af6a81af5ce8a06d7acecc9dba006309475157d85713884.jpg",
                  "Whatsapp.jpg": "embedded\u002F45bd52231e99fd9502d43efd8fabe2b56f8bc3086316b76e6cee148d6eb96202.jpg",
                  "Whatsapp_scram.jpg": "embedded\u002Fca0e06f39d78b86b738c41a22ba71d462f8fc96e9747ce795edfa8cf2100df21.jpg",
                  "Facebook.jpg": "embedded\u002F15c6f60158be6195f27625bf178035a484f92f3eb8c41c93a808bc9d7fe8c65c.jpg",
                  "Facebook_scram.jpg": "embedded\u002F0c30f9f13eaf42fed3d1b529d5ef04c4698b66dfadd45cef25d311e63bc4c891.jpg",
                  "Instagram.jpg": "embedded\u002F0e7d8676b4c2160bbfa93e2eb3a841819000509ed00582598c3b318f9d9370b9.jpg",
                  "Instagram_scram.jpg": "embedded\u002Fee6c82f10286c888468a2ec3fbe541ccb76763a2a0f3dfa86b70af878aa65ad7.jpg",
                  "Messenger.jpg": "embedded\u002F059852719ebce2f3630c48d673101d3ecb0f4fa719b91570cfc14d1b9112406b.jpg"
                },
                "correctResponse": "${ parameters.value }"
              },
              {
                "type": "lab.html.Screen",
                "parameters": {},
                "responses": {},
                "messageHandlers": {},
                "title": "WHITE",
                "timeout": "1500",
                "files": {}
              }
            ]
          }
        }
      ]
    },
    {
      "messageHandlers": {},
      "type": "lab.html.Screen",
      "responses": {
        "keypress(Space)": "continue"
      },
      "title": "EINDE BLOK 1 (GO = SNS)",
      "content": "\u003Cmain\u003E\n\u003Cp\u003E Je bent klaar met het eerste blok! Indien je dit wil, kan je nu kort even pauze nemen.  \u003C\u002Fp\u003E\n\n\u003C\u002Fmain\u003E\n\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\n  \u003Ch4\u003E\u003Cb\u003EDruk op de \u003Ckbd\u003E spatiebalk \u003C\u002Fkbd\u003E om verder te gaan met het tweede blok.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \n\u003C\u002Ffooter\u003E",
      "timeout": "Never",
      "parameters": {},
      "files": {}
    },
    {
      "type": "lab.flow.Sequence",
      "parameters": {},
      "responses": {},
      "messageHandlers": {},
      "title": "BLOK 2 (GO = SCRAM)",
      "files": {},
      "content": [
        {
          "messageHandlers": {},
          "type": "lab.html.Screen",
          "responses": {
            "keypress(Space)": "continue"
          },
          "title": "UITLEG BLOK 2  (GO = SCRAM)",
          "content": "\u003Cmain\u003E\n  \u003Ch1\u003E BLOK 2 (GO = SCRAM) \u003C\u002Fh1\u003E\n  \u003Cp\u003E Tijdens dit eerste blok zal je moeten reageren op de verhakkelde logo's van \u003Cb\u003E social media en communicatie-applicaties \u003C\u002Fb\u003E, nl. Instagram, Facebook, Messenger, Whatsapp.\u003C\u002Fp\u003E\n  \u003Cbr\u003E\n  \u003Cimg src=\"${ this.files['samen_knip_verhak.jpg'] }\" height= auto width= 350\u003E\n  \u003Cbr\u003E\n  \u003Cp\u003E Als je deze 'verhakkelde' logo's ziet verschijnen, druk je zo snel mogelijk op \u003Ckbd\u003EJ\u003C\u002Fkbd\u003E. Wanneer je de logo's te zien krijg, mag je \u003Cb\u003Eniet reageren\u003C\u002Fb\u003E en wacht je tot die afbeeldingen verdwijnen. Hier probeer je dus juist \u003Cb\u003E niet \u003C\u002Fb\u003E reageren. \u003C\u002Fp\u003E\n  \u003Cbr\u003E\n\u003C\u002Fmain\u003E\n\u003Cfooter class = \"content-vertical-center content-horizontal-center\"\u003E\n   \u003Ch4\u003E\u003Cb\u003EDruk op de \u003Ckbd\u003E spatiebalk \u003C\u002Fkbd\u003E om een visualisatie te zien van deze taak.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \n\u003C\u002Ffooter\u003E\n",
          "parameters": {},
          "files": {
            "samen_knip_verhak.jpg": "embedded\u002F150fef9892dc5f266891983e6f880b00053d9f3c0faddfa5cb7519588ccbe1d8.jpg"
          }
        },
        {
          "messageHandlers": {},
          "type": "lab.html.Screen",
          "responses": {
            "keypress(Space)": "continue"
          },
          "title": "VISUAL UITLEG BLOK 2 (GO = SCRAM)",
          "content": "\u003Cmain\u003E\n   \u003Cp\u003E Hieronder krijg je een visualisatie van de voorgaande uitleg over hoe je moet reageren tijdens dit twee blok. \u003C\u002Fp\u003E\n  \u003Cbr\u003E\n  \u003Cp\u003E Concreet moet je dus op \u003Ckbd\u003E J \u003C\u002Fkbd\u003E bij de volgende vier 'verhakkelde' logo's: \u003C\u002Fp\u003E\n\n \u003Cimg src=\"${ this.files['samen_knip_verhak.jpg'] }\" height= auto width= 350\u003E\n  \n\u003Cbr\u003E\n\n \u003C\u002Fmain\u003E\n \u003Cfooter class = \"content-vertical-center content-horizontal-center\"\u003E\n   \u003Ch4\u003E\u003Cb\u003EDruk op de \u003Ckbd\u003E spatiebalk \u003C\u002Fkbd\u003E om te starten met het tweede blok.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \n\u003C\u002Ffooter\u003E\n",
          "parameters": {},
          "files": {
            "samen_knip_verhak.jpg": "embedded\u002F150fef9892dc5f266891983e6f880b00053d9f3c0faddfa5cb7519588ccbe1d8.jpg"
          }
        },
        {
          "type": "lab.flow.Loop",
          "parameters": {},
          "templateParameters": [
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Instagram.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Messenger.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Whatsapp.jpg",
              "value": "NO GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Facebook_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Instagram_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Messenger_scram.jpg",
              "value": "GO"
            },
            {
              "STIMULI": "Whatsapp_scram.jpg",
              "value": "GO"
            }
          ],
          "responses": {},
          "messageHandlers": {},
          "title": "BLOK 2 LOOP",
          "files": {},
          "sample": {
            "mode": "draw",
            "n": "10"
          },
          "shuffleGroups": [],
          "template": {
            "type": "lab.flow.Sequence",
            "parameters": {},
            "responses": {},
            "messageHandlers": {},
            "title": "BLOK 2 TRIAL",
            "files": {},
            "content": [
              {
                "type": "lab.html.Screen",
                "parameters": {},
                "responses": {},
                "messageHandlers": {},
                "title": "FIXATION",
                "content": "\u003Cmain class=\"content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Cdiv style=\"font-size: 3.5rem\"\u003E\r\n    +\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fmain\u003E\r\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Cp\u003E\u003Ch4\u003E\r\n    Druk op zo snel mogelijk op \u003Ckbd\u003EJ\u003C\u002Fkbd\u003E indien je een verhakkeld logo van Instagram, Facebook, Messenger of Whatsapp te zien krijgt. \r\n  \u003C\u002Fp\u003E\u003C\u002Fh4\u003E\r\n\u003C\u002Ffooter\u003E",
                "timeout": "200",
                "files": {}
              },
              {
                "type": "lab.html.Screen",
                "parameters": {},
                "responses": {
                  "keypress(j) window": "GO"
                },
                "messageHandlers": {},
                "title": "STIMULUS",
                "content": "\u003Cstyle\u003E\r\n  .topleft {\r\n    position: absolute;\r\n    top: 150px;\r\n    left: 40px;\r\n    font-size: 30px;\r\n  }\r\n  .topright {\r\n    position: absolute;\r\n    top: 150px;\r\n    right: 40px;\r\n    font-size: 30px;\r\n  }\r\n\u003C\u002Fstyle\u003E  \r\n\u003Cheader\u003E\r\n Indien nodig, reageer op de afbeelding. \r\n\u003C\u002Fheader\u003E\r\n\r\n\u003Cmain\u003E\r\n  \u003Cimg src=\"${ this.files[ parameters.STIMULI ] }\" height= auto width= 350\u003E\r\n\r\n\u003C\u002Fmain\u003E\r\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\r\n  \u003Cp\u003E\u003Ch4\u003E\r\n    Druk op zo snel mogelijk op \u003Ckbd\u003EJ\u003C\u002Fkbd\u003E indien je een verhakkelt logo van Instagram, Facebook, Messenger of Whatsapp te zien krijgt. \r\n  \u003C\u002Fp\u003E\u003C\u002Fh4\u003E\r\n\u003C\u002Ffooter\u003E",
                "timeout": "1500",
                "files": {
                  "Messenger_scram.jpg": "embedded\u002Fa79abe0617b0d2631af6a81af5ce8a06d7acecc9dba006309475157d85713884.jpg",
                  "Whatsapp.jpg": "embedded\u002F45bd52231e99fd9502d43efd8fabe2b56f8bc3086316b76e6cee148d6eb96202.jpg",
                  "Whatsapp_scram.jpg": "embedded\u002Fca0e06f39d78b86b738c41a22ba71d462f8fc96e9747ce795edfa8cf2100df21.jpg",
                  "Facebook.jpg": "embedded\u002F15c6f60158be6195f27625bf178035a484f92f3eb8c41c93a808bc9d7fe8c65c.jpg",
                  "Facebook_scram.jpg": "embedded\u002F0c30f9f13eaf42fed3d1b529d5ef04c4698b66dfadd45cef25d311e63bc4c891.jpg",
                  "Instagram.jpg": "embedded\u002F0e7d8676b4c2160bbfa93e2eb3a841819000509ed00582598c3b318f9d9370b9.jpg",
                  "Instagram_scram.jpg": "embedded\u002Fee6c82f10286c888468a2ec3fbe541ccb76763a2a0f3dfa86b70af878aa65ad7.jpg",
                  "Messenger.jpg": "embedded\u002F059852719ebce2f3630c48d673101d3ecb0f4fa719b91570cfc14d1b9112406b.jpg"
                },
                "correctResponse": "${ parameters.value }"
              },
              {
                "type": "lab.html.Screen",
                "parameters": {},
                "responses": {},
                "messageHandlers": {},
                "title": "WHITE",
                "timeout": "1500",
                "files": {}
              }
            ]
          }
        }
      ]
    },
    {
      "messageHandlers": {},
      "type": "lab.html.Screen",
      "responses": {
        "keypress(Space)": "continue"
      },
      "title": "BEDANKT",
      "content": "\u003Cmain\u003E\n\u003Cp\u003E Je bent klaar met de volledige computertaak! Bedankt voor deelname, dit kan ons erg interessante gegevens opleveren, die we bijvoorbeeld misschien kunnen koppelen met maten van jouw smartphonegebruik, gemeten via MobileDNA.  \u003C\u002Fp\u003E\n\u003Cbr\u003E\n\u003Cp\u003E We houden jullie op de hoogte van onze bevindingen! \u003C\u002Fp\u003E\n\n\u003C\u002Fmain\u003E\n\n\u003Cfooter class=\"content-vertical-center content-horizontal-center\"\u003E\n  \u003Ch4\u003E\u003Cb\u003EDruk op de \u003Ckbd\u003E spatiebalk \u003C\u002Fkbd\u003E om deze computertaak af te sluiten.\u003C\u002Fh4\u003E\u003C\u002Fb\u003E \n\u003C\u002Ffooter\u003E",
      "timeout": "Never",
      "parameters": {},
      "files": {}
    }
  ]
})

// Let's go!
study.run()